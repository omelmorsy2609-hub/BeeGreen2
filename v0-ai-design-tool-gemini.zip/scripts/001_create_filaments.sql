-- Create filaments table for the store
CREATE TABLE IF NOT EXISTS public.filaments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  image_url TEXT,
  color TEXT DEFAULT '#7FB628',
  properties TEXT[] DEFAULT '{}',
  in_stock BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.filaments ENABLE ROW LEVEL SECURITY;

-- Allow public read access (anyone can view filaments)
CREATE POLICY "filaments_public_read" ON public.filaments
  FOR SELECT
  USING (true);

-- Insert some sample filaments
INSERT INTO public.filaments (name, price, image_url, color, properties, in_stock) VALUES
  ('PLA Pro - Matte Black', 24.99, NULL, '#1a1a1a', ARRAY['1.75mm', '1kg Spool', '205-225°C'], true),
  ('PETG - Crystal Clear', 29.99, NULL, '#e0e0e0', ARRAY['1.75mm', '1kg Spool', '230-250°C'], true),
  ('TPU Flex - Neon Green', 34.99, NULL, '#39ff14', ARRAY['1.75mm', '500g Spool', '220-240°C'], true),
  ('ABS+ - Arctic White', 22.99, NULL, '#f5f5f5', ARRAY['1.75mm', '1kg Spool', '230-260°C'], true),
  ('Carbon Fiber PLA', 44.99, NULL, '#2d2d2d', ARRAY['1.75mm', '750g Spool', '200-230°C'], false),
  ('Silk PLA - Rose Gold', 28.99, NULL, '#b76e79', ARRAY['1.75mm', '1kg Spool', '190-220°C'], true);
