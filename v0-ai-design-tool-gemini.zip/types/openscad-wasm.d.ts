declare module "openscad-wasm" {
  export interface OpenScadFS {
    writeFile(path: string, data: string | ArrayBufferView): void
    readFile(path: string, opts?: { encoding: "utf8" }): string
    readFile(path: string, opts: { encoding: "binary" }): Uint8Array
    unlink(path: string): void
  }

  export interface OpenScadRawInstance {
    callMain(args: string[]): number
    FS: OpenScadFS
  }

  export interface OpenScadInitOptions {
    noInitialRun?: boolean
    print?: (text: string) => void
    printErr?: (text: string) => void
  }

  export interface OpenScadInstance {
    renderToStl(code: string): Promise<string>
    getInstance(): OpenScadRawInstance
  }

  export function createOpenSCAD(options?: OpenScadInitOptions): Promise<OpenScadInstance>
}
